#ifndef STRAIGHTLINE_PROG1_H_
#define STRAIGHTLINE_PROG1_H_

#include "straightline/slp.h"

A::Stm *prog();
A::Stm *prog();
A::Stm *prog_prog();
A::Stm *right_prog();
A::Stm *error_prog();

#endif  // STRAIGHTLINE_PROG1_H_
