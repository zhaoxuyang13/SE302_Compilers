#ifndef TIGER_SEMANT_SEMANT_H_
#define TIGER_SEMANT_SEMANT_H_

#include "tiger/absyn/absyn.h"

namespace SEM {

void SemAnalyze(A::Exp *root);

}  // namespace SEM

#endif  // TIGER_SEMANT_SEMANT_H_