#include "tiger/regalloc/color.h"

namespace COL {

Result Color(G::Graph<TEMP::Temp> ig, TEMP::Map initial, TEMP::TempList regs,
             LIVE::MoveList* moves) {
  // TODO: Put your codes here (lab6).
  return Result();
}

}  // namespace COL