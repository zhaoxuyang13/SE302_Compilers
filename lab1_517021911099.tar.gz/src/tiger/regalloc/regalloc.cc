#include "tiger/regalloc/regalloc.h"

namespace RA {

Result RegAlloc(F::Frame* f, AS::InstrList* il) {
  // TODO: Put your codes here (lab6).
  return Result();
}

}  // namespace RA