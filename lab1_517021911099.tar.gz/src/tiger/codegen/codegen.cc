#include "tiger/codegen/codegen.h"

namespace CG {

AS::InstrList* Codegen(F::Frame* f, T::StmList* stmList) {
  // TODO: Put your codes here (lab6).
  return nullptr;
}

}  // namespace CG