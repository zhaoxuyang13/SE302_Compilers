#ifndef TIGER_TRANSLATE_PRINTTREE_H_
#define TIGER_TRANSLATE_PRINTTREE_H_

#include "tiger/translate/tree.h"

namespace T {

void PrintStmList(FILE *out, T::StmList stmList);

}  // namespace T

#endif