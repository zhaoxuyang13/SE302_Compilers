#include "tiger/liveness/liveness.h"

namespace LIVE {

LiveGraph Liveness(G::Graph<TEMP::Temp>* flowgraph) {
  // TODO: Put your codes here (lab6).
  return LiveGraph();
}

}  // namespace LIVE